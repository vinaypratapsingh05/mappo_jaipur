"""Validate the Jaipur assets before training or SUMO integration."""
from pathlib import Path
import csv, re

root=Path('data')
net=(root/'Jaipur.net.xml').read_text(encoding='utf-8')
tls=re.findall(r'<tlLogic id="([^"]+)"', net)
rows=list(csv.DictReader(open(root/'normal_data_v3.csv', encoding='utf-8')))
nodes=sorted(set(r['Node_ID'] for r in rows))
print('Traffic-light controllers:', tls)
print('CSV intersections:', nodes)
print('CSV records:', len(rows))
route=root/'Jaipur.routed.rou.xml'
print('SUMO route file:', 'available' if route.exists() else 'MISSING (required for SUMO rollout)')
assert len(tls)==4 and len(nodes)==4, 'Expected four intersections/controllers'
