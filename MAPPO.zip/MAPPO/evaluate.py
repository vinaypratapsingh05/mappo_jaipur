"""Run deterministic CF-ST-MAPPO evaluation for one complete 24-hour CSV cycle."""
import argparse, json
from pathlib import Path
import numpy as np, torch
from torch.utils.tensorboard import SummaryWriter
from cf_st_mappo import Config, CFSTMAPPONet, CSVTrafficEnv, MAPPO, adjacency_from_network

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',default='models/jaipur_cf_st_mappo_actor.pt'); p.add_argument('--data',default='data/normal_data_v3.csv')
    p.add_argument('--network',default='data/Jaipur.net.xml'); p.add_argument('--hours',type=int,default=24); p.add_argument('--logdir',default='outputs/tensorboard/evaluation')
    a=p.parse_args(); torch.set_num_threads(1); cfg=Config(); env=CSVTrafficEnv(a.data,cfg)
    net=CFSTMAPPONet(config=cfg); net.actor.load_state_dict(torch.load(a.model, map_location='cpu', weights_only=True)['state_dict'])
    agent=MAPPO(net, adjacency_from_network(a.network),cfg); writer=SummaryWriter(a.logdir); total=0.; queues=[]
    steps=min(a.hours*60, len(env.times))  # CSV has one observation per minute.
    # CSV telemetry is exogenous, so all 24h states can be inferred in batches. This
    # keeps a complete day evaluation practical on a CPU while reward remains sequential.
    preview=CSVTrafficEnv(a.data,cfg); preview_obs=preview.reset(); observations=[]
    for _ in range(steps):
        observations.append(preview_obs); preview_obs,_,done,_=preview.step(np.zeros(4, dtype=int))
        if done: break
    actions=[]
    with torch.no_grad():
        for start in range(0,len(observations),256):
            group=observations[start:start+256]
            traffic=torch.tensor(np.stack([x[0] for x in group]),dtype=torch.float32)
            context=torch.tensor(np.stack([x[1] for x in group]),dtype=torch.float32)
            states=net.fuse(traffic,context,agent.adj)
            actions.extend(net.actor(states).argmax(-1).numpy())
    obs=env.reset()
    for step,action in enumerate(actions):
        obs,reward,done,info=env.step(action)
        total+=float(reward.mean()); queues.append(info['mean_queue'])
        writer.add_scalar('evaluation/reward',float(reward.mean()),step); writer.add_scalar('traffic/mean_queue',info['mean_queue'],step)
        if done: break
    result={'hours':a.hours,'steps':len(queues),'total_reward':total,'mean_reward':total/len(queues),'mean_queue':float(np.mean(queues))}
    writer.add_hparams({'hours':a.hours},{'evaluation/total_reward':total,'traffic/mean_queue':result['mean_queue']}); writer.close()
    Path('outputs/evaluation_24h.json').write_text(json.dumps(result,indent=2)); print(json.dumps(result,indent=2))
if __name__=='__main__': main()
