# Jaipur CF-ST-MAPPO

Implementation of the supplied Context-Fused Spatiotemporal MAPPO design for the four Jaipur intersections.

- `data/Jaipur.net.xml`, `data/simulation.sumocfg`, and `data/normal_data_v3.csv` are the supplied inputs.
- HetSG features retain each approach's cars, two-wheelers, three-wheelers, buses, plus delay; vehicle footprint weights distinguish heterogeneous demand.
- A normalized controller graph feeds GCN message passing, then a 5-step GRU. A Transformer encodes rainfall/visibility/temperature/time/weekend context.
- Training uses a global centralized critic, while `models/jaipur_cf_st_mappo_actor.pt` contains only the small decentralized actor.
- Actions are two legal movement groups (N/S or E/W). The SUMO programs already contain mandatory yellow transitions; `Config` records the 4-second safety policy.
- PPO uses clipped ratios (0.2), GAE, entropy regularization, and gradient clipping. Reward is max-pressure/delay with a rain-scaled phase-flicker penalty.

Run a short training run:

```powershell
python train.py --updates 45
```

`45 × 32 = 1,440` CSV decisions, i.e. a complete 24-hour training cycle at one-minute resolution. Test the trained actor for the same 24-hour period and write reward/queue charts:

```powershell
python evaluate.py --hours 24
tensorboard --logdir outputs/tensorboard
```

Validate the supplied assets with `python validate_inputs.py`.

The CSV environment enables fast reproducible training. The bundled SUMO configuration runs a full 24-hour horizon (`0`–`86,400` seconds) and references the included `Jaipur.routed.rou.xml` route file.
