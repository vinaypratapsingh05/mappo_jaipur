import argparse, json, random
from pathlib import Path
import numpy as np, torch
from cf_st_mappo import Config, CFSTMAPPONet, CSVTrafficEnv, MAPPO, adjacency_from_network

def main():
    p=argparse.ArgumentParser(description='Train CF-ST-MAPPO on Jaipur data')
    p.add_argument('--data',default='data/normal_data_v3.csv'); p.add_argument('--network',default='data/Jaipur.net.xml')
    p.add_argument('--updates',type=int,default=45,help='45 x 32 control decisions = one 24-hour CSV cycle')
    p.add_argument('--output',default='models/jaipur_cf_st_mappo_actor.pt'); p.add_argument('--logdir',default='outputs/tensorboard/train')
    args=p.parse_args(); cfg=Config(); torch.set_num_threads(1); random.seed(cfg.seed); np.random.seed(cfg.seed); torch.manual_seed(cfg.seed)
    env=CSVTrafficEnv(args.data,cfg); model=CFSTMAPPONet(config=cfg); trainer=MAPPO(model, adjacency_from_network(args.network), cfg)
    metrics=trainer.train(env,args.updates,args.logdir); Path(args.output).parent.mkdir(parents=True,exist_ok=True); trainer.save_actor(args.output)
    Path('outputs/training_metrics.json').write_text(json.dumps(metrics,indent=2)); print(json.dumps(metrics[-1],indent=2)); print('Saved decentralized actor:',args.output)
if __name__=='__main__': main()
